Data on the temperature dependence of the thermopower of an E-type thermocouple (a junction of constantan and chromel). 

First column: Temperature in degrees Celcius [C]

Second column: Thermopower (aka Seebeck coefficient) in Volts per Kelvin [V/K]

Third column: 95% confidence interval for the measured thermopower.
