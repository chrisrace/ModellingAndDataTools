Binned data on the number of cracks of different lengths that appeared in a steel sample that had been submerged in boiling, concentrated magnesium chloride solution for 10 hours prior to been tensile tested.

First column: Left side of each bin (microns)
Second column: Right side of each bin (microns)
Third column: Centre point of each bin (microns)
Fourth column: Number of cracks in each bin