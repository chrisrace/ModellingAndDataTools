Stress-strain data for a tensile test performed on magnesium metal.

First column: Strain in percent (%)

Second: Stress in gigapascals (GPa)
